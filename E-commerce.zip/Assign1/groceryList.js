import React from 'react';

function GroceryList({ items, onTogglePurchased, onDeleteItem }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item._id}>
          <span
            onClick={()