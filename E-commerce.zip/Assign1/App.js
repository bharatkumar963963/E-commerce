import React, { useState, useEffect } from 'react';
import axios from 'axios';
import GroceryList from './groceryList';
import AddItemForm from './AddItemForm';

function App() {
  const [items, setItems] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const result = await axios.get('/api/items');
      setItems(result.data);
    };
    fetchData();
  }, []);

  const addItem = async (name) => {
    const result = await axios.post('/api/items', { name });
    setItems([...items, result.data]);
  };

  const togglePurchased = async (id) => {
    const result = await axios.put(`/api/items/${id}`);
    setItems(
      items.map((item) =>
        item._id === result.data._id ? result.data : item
      )
    );
  };

  const deleteItem = async (id) => {
    await axios.delete(`/api/items/${id}`);
    setItems(items.filter((item) => item._id !== id));
  };

  return (
    <div>
      <h1>Grocery List</h1>
      <AddItemForm onAddItem={addItem} />
      <GroceryList
        items={items}
        onTogglePurchased={togglePurchased}
        onDeleteItem={deleteItem}
      />
    </div>
  );
}

export default App;