require('dotenv').config() // this is used for connecting to .env file
const express = require('express');
const bodyParser = require('body-parser');
const { Schema } = require("mongoose");
const Mongoose = require('mongoose');
Mongoose.Promise = global.Promise;
Mongoose.set('strictQuery',true);
const url = process.env.DB_URL;
const cors = require('cors');

const app = express();

app.use(cors());
app.use(bodyParser.json())

const items = Schema({
  name: String,
  purchased: Boolean
},{collection:'items'});

function item(){
  return Mongoose.connect(url,{useNewUrlParser:true,useUnifiedTopology:true}).then((database)=>{
    return database.model('items',items)
  }).catch((error)=>{
    let err = new Error("couldn't connect to database" + error);
    err.status = 500;
    throw err
  })
}

app.post('/api/get-items', async (req, res) => {
  const collection = await item();
  const data = await collection.find({name:req.body.name});
  if(data.length > 0){
    res.send(data)
  }
 else{
  res.send("no data matched!!")
 }
});

app.post('/api/post-items', async (req, res) => {
  const collection = await item();
  const data = await collection.insertMany(req.body);
  if(data.length>0){
    res.send('inserted')
  }
  else{
    res.send('unable to insert')
  }
});

app.post('/api/update-items', async (req, res) => {
  const collection = await item();
  const data = await collection.updateOne({"name":req.body.name},{$set : {"purchased":false}});
  if(data.modifiedCount == 1){
    res.send('updated')
  }
  else{
    res.send('unable to update')
  }
});

app.post('/api/delete-items', async (req, res) => {
  const collection = await item();
  const data = await collection.deleteMany({"name":req.body.name});
  if(data.deletedCount > 1){
    res.send('deleted')
  }
  else{
    res.send('unable to delete')
  }
});

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Server running on port ${port}`));